/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question9;

/**
 *
 * @author YaswantLakkaraju
 */
public class UnderGraduate implements University {

  // implementation of abstract method
  public void getName(String name) {
    System.out.println("UnderGraduate University : " + name);
  }

    
}