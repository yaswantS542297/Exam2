/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question9;

/**
 *
 * @author YaswantLakkaraju
 */
public class Main {
  public static void main(String[] args) {
    System.out.println("Question 9 : Yaswant Lakkaraju");
    UnderGraduate University = new UnderGraduate();
    University.getName("Amrita Vishwa Vidyapeetham");
  }
}
