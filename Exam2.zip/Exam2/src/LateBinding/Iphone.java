/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LateBinding;

/**
 *
 * @author YaswantLakkaraju
 */
public class Iphone{
   //Overridden Method
   public void SmartPhone()
   {
       System.out.println("Iphone is a SmartPhone");
   }
}
