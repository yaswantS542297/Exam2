/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LateBinding;

/**
 *
 * @author YaswantLakkaraju
 */
public class Samsung extends Iphone{
   //Overriding Method
   public void SmartPhone(){
       System.out.println("Samsung is a SmartPhone");
   }
   public static void main( String args[]) {
       /* Reference is of Human type and object is
        * Boy type
        */
       System.out.println("Question 4 : Yaswant Lakkaraju");
       Iphone L = new Samsung();
       /* Reference is of HUman type and object is
        * of Human type.
        */
       Iphone Y = new Iphone();
       L.SmartPhone();
       Y.SmartPhone();
   }
}
