/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question4;

/**
 *
 * @author YaswantLakkaraju
 */
public class JavaTeacher extends Teacher{
   String Subject  = "Object Oriented Programming";
   public static void main(String args[]){
       System.out.println("Question 4 : Yaswant Lakkaraju");
	JavaTeacher obj = new JavaTeacher();
	System.out.println(obj.University);
	System.out.println(obj.Designation);
	System.out.println(obj.Subject);
	obj.does();
   }
}
