/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question7;

/**
 *
 * @author YaswantLakkaraju
 */

public class Main
{
    public enum Sports{
	  Cricket, 
	  FootBall, 
	  VolleyBall, 
	  BasketBall
}
   public static void main(String args[]){
       System.out.println("Question 7 : Yaswant Lakkaraju");
	Sports L = Sports.Cricket;  
	if(L == Sports.VolleyBall) {
	    System.out.println("Sport : VolleyBall");
	} else if(L == Sports.BasketBall) {
	    System.out.println("Sport : WestBasketBall");
	  } else if(L == Sports.Cricket) {
	      System.out.println("Sport : Cricket");
  	    } else {
		System.out.println("Sport : FootBall");
	      }
   }
}
