/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question42;

/**
 *
 * @author YaswantLakkaraju
 */
public class MainClass {
public static void main(String[] args)
    {
  System.out.println("Question 4 : Yaswant Lakkaraju");
        Horn L;
  
        L = new ModernVehicles();
        L.Print();
  
        L = new OlderVehicles();
        L.Print();
    }
}