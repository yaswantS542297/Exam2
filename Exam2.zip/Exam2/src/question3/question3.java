/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author YaswantLakkaraju
 */
public class question3 {

    public static void main(String[] args) {
		// Create an array list of objects
        System.out.println("Question 3 : Yaswant Lakkaraju");
        ArrayList<Object> arrayList = new ArrayList<Object>();
        arrayList.add(new Loan(100000,12));
        arrayList.add(new Date());
        arrayList.add("Tested");
        
        for(Object L : arrayList){
            System.out.println(L.toString());
        }
    }
}