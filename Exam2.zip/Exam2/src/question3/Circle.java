/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

/**
 *
 * @author YaswantLakkaraju
 */
public class Circle {
    double L,Y,N;

    public Circle(double L, double Y, double N) {
        this.L = L;
        this.Y = Y;
        this.N = N;
    }

    @Override
    public String toString() {
        return "Circle{" +
                "L=" + L +
                ", Y=" + Y +
                ", N=" + N +
                '}';
    }
}
