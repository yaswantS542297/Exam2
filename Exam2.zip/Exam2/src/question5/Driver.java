/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question5;

/**
 *
 * @author YaswantLakkaraju
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person PERSON = new Person("Yaswant");
        Student STUDENT = new Student("Ram");
        Employee EMPLOYEE = new Employee("Saketh");
        Faculty FACULTY = new Faculty("Abhirup");
        Staff STAFF = new Staff("Vatsav");
        System.out.println("Question 5 : Yaswant Lakkaraju");
        System.out.println("**************************");
        System.out.println(PERSON.toString());
        System.out.println("**************************");
        System.out.println(STUDENT.toString());
        System.out.println("**************************");
        System.out.println(EMPLOYEE.toString());
        System.out.println("**************************");
        System.out.println(FACULTY.toString());
        System.out.println("**************************");
        System.out.println(STAFF.toString());
        System.out.println("**************************");
    }

}
