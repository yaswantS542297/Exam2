/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question6;
import java.util.*;
/**
 *
 * @author YaswantLakkaraju
 */
public class Main
{
public static void main(String []args)

{
System.out.println("Question 6 : Yaswant Lakkaraju");
System.out.println("Enter three sides: ");
Scanner SCANNER=new Scanner(System.in);

double side1, side2, side3;

side1=SCANNER.nextDouble();
side2=SCANNER.nextDouble();
side3=SCANNER.nextDouble();
Triangle triangle=new Triangle(side1, side2, side3);

System.out.println("Enter the color: ");

String color;

color=SCANNER.next();

System.out.println("Enter true/false for filled : ");

boolean filled;

filled=SCANNER.nextBoolean();


triangle.setColor(color);

triangle.setFilled(filled);

System.out.println("Area is "+triangle.getArea());

System.out.println("Perimeter is "+triangle.getPerimeter());

System.out.println("Color is " +triangle.getColor());

System.out.println("Filled is "+(triangle.isFilled()));

}
}
