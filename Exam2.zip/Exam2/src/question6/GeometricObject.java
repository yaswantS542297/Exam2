/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question6;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author YaswantLakkaraju
 */
import java.io.*;
import java.util.Scanner;


// Base class
public class GeometricObject
{

      void setSide1(double S1)
      {
         side1 = S1;
      }
      void setSide2(double S2)
      {
         side2 = S2;
      }
       void setSide3(double S3)
      {
         side3 = S3;
      }
      double getSide1()
      {
        return (side1);
      }
      double getSide2()
      {
        return (side2);
      }
       double getSide3()
      {
         return (side3);
      }
      void setColor(String C)
      {
      color = C;
      }
      String getColor()
      {
      return(color);
      }
      void setFilled(boolean F)
      {
      filled = F;
      }
      boolean isFilled()
      {
      return(filled);
      }

      double side1,side2,side3;
      String color;
      boolean filled;
    
};
