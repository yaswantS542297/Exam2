/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question6;

/**
 *
 * @author YaswantLakkaraju
 */
public class Triangle extends GeometricObject
{

double S1,S2,S3,PERI,P,PD,A;

     Triangle()
   {
   setSide1(1.0);
   setSide2(1.0);
   setSide3(1.0);

   }
    Triangle(double S1,double S2,double S3)
   {
   setSide1(S1);
   setSide2(S2);
   setSide3(S3);

   }

      double getArea()
      {
      P=getPerimeter()/2;
      PD=P*(P-S1)*(P-S2)*(P-S3);
      A=Math.sqrt(PD);
         return (A);
      }
      double getPerimeter()
      {
      S1=getSide1();
      S2=getSide2();
      S3=getSide3();
      PERI=S1+S2+S3;
      return (S1+S2+S3);
      }
};
