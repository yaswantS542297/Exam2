/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;
import java.util.*;
/**
 *
 * @author YaswantLakkaraju
 */
public class TwoDimensional {
 public static void main(String[] args) {

        int[][] m1 = new int[3][3];
        int[][] m2 = new int[3][3];

        Scanner inputScanner = new Scanner(System.in);
        System.out.println("Question 2 : Yaswant Lakkaraju");
        System.out.print("Enter list1: ");
        for (int L = 0; L < m1.length; L++)
            for (int Y = 0; Y < m1[L].length; Y++)
                m1[L][Y] = inputScanner.nextInt();
        System.out.print("Enter list2: ");
        for (int L = 0; L < m2.length; L++)
            for (int Y = 0; Y < m2[L].length; Y++)
                m2[L][Y] = inputScanner.nextInt();

        if (equals(m1, m2)) {
            System.out.println("The two arrays are strictly identical.");
        } else {
            System.out.println("The two arrays are not strictly identical");
        }
    }

    public static boolean equals(int[][] m1, int[][] m2) {

        if (m1.length != m2.length || m1[0].length != m2[0].length) return false;

        for (int L = 0; L < m1.length; L++) {
            for (int Y = 0; Y < m1[L].length; Y++) {

                if (m1[L][Y] != m2[L][Y]) return false;
            }
        }

        return true;
    }
}
