/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;


/**
 *
 * @author YaswantLakkaraju
 */
//Header file section
import java.util.*;

//main class
public class RemoveDuplicate
{
// main method
public static void main(String[] args)
{
  //Create a ArrayList's class
  ArrayList<Integer> list = new ArrayList<Integer>();
  
  //Create a Scanner's class object
  Scanner inputScanner = new Scanner(System.in);

  //Prompt and read input from the user
  System.out.println("Question 1 : Yaswant Lakkaraju");
  
  System.out.print("Enter ten integers: ");
    int[] inputValue = new int[10];
     for (int L = 0; L < 10; L++)
     {
      inputValue[L] = inputScanner.nextInt();
      list.add(inputValue[L]);
     }

  inputScanner.close();

  //Call the method
  removeDuplicate(list);

  //Display output
  System.out.print("The Distinct integers: ");
  for (int L = 0; L < list.size(); L++)
  {
   System.out.print(list.get(L) + " ");
  }
}

//This method that removes the duplicate elements
//from an array list of integers
public static void removeDuplicate(ArrayList<Integer> list)
{
  for (int L = 0; L < list.size(); L++)
  {
   Integer List = list.get(L);
   List DuplicateList = list.subList(L + 1, list.size());
   while (DuplicateList.contains(List))
   {
    DuplicateList.remove(List);
   }
  }
}
}

